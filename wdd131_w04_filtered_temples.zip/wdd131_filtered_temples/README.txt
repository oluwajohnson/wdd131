WDD 131 W04 - Filtered Temple Album

Files:
- filtered-temples.html
- styles/filtered-temples.css
- styles/filtered-temples-large.css
- scripts/filtered-temples.js

Setup:
1. Copy filtered-temples.html into the root of your existing wdd131 repository.
2. Copy the two CSS files into your existing styles folder.
3. Copy filtered-temples.js into your existing scripts folder.
4. Open filtered-temples.html with Live Server.
5. Replace [Your Full Name] and [Your State or Country] in the footer and author metadata.

Features:
- Temple cards are generated from the JavaScript temples array.
- Each image uses native lazy loading (loading="lazy").
- Home, Old, New, Large and Small navigation items filter the array.
- Responsive hamburger menu retained from the original Temple Album.
- Copyright year and last-modified date are populated dynamically.

The temple images are remote image URLs supplied in the assignment or added for the three additional temple records. An internet connection is required for the images to load.
